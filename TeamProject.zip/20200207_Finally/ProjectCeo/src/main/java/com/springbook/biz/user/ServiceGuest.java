package com.springbook.biz.user;

import java.util.List;

public interface ServiceGuest {
	List<GuestVO> getMenuList(GuestVO gvo);
}
